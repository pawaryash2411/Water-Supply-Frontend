import React from 'react'
import AllRoutes from "../src/AllRoutes/AllRoutes"
// import Rinky from './Component/Admin/Component/Pages/Rinky'

const App = () => {
  return (
    <>
    <AllRoutes/>
 {/* <Rinky></Rinky> */}
    </>
  )
}

export default App