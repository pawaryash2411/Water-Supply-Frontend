import UserDashboard from "../Component/Pages/UserDashboard/UserDashboard";




let UserRoutes = [
    {
        index : true,
        element :<UserDashboard />
      },
]


export default UserRoutes;