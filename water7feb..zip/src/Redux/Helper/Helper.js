export const API_URL = "http://localhost:8000/api";
// export const API_URL = "https://water-supply.onrender.com/api";